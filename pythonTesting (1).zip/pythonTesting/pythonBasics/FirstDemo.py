print("hello")
# here are the comments i have defined

a = 3
print(a)

Str = "Hello World"
print(Str)

b, c, d = 5, 6.4, "Great"

#print("Value is"+b+"fdfd")

print("{} {}".format("Value is", b))

print(type(b))

print(type(c))
print(type(d))







